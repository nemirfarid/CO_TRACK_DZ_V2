import 'dart:io';

import 'package:excel/excel.dart';
import 'package:flutter_file_dialog/flutter_file_dialog.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';

import '../models/intervention.dart';

class ExportService {
  /// Creates an XLSX file for the requested period and opens Android's
  /// system save dialog (Storage Access Framework). The user chooses where
  /// to save it, for example the Downloads folder. No intervention/photo is
  /// deleted or modified by this operation.
  static Future<String?> exportRange({
    required String enterprise,
    required List<Intervention> items,
    required DateTime start,
    required DateTime end,
  }) async {
    final startDate = DateTime(start.year, start.month, start.day);
    final endDate = DateTime(end.year, end.month, end.day, 23, 59, 59);
    final selected = items.where((item) {
      final created = DateTime.tryParse(item.createdAt);
      return created != null &&
          !created.isBefore(startDate) &&
          !created.isAfter(endDate);
    }).toList()
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));

    if (selected.isEmpty) {
      throw Exception('Aucune intervention pour cette période.');
    }

    final excel = Excel.createExcel();
    final sheet = excel['Interventions'];
    sheet.appendRow([
      TextCellValue('DATE_HEURE'),
      TextCellValue('REFERENCE_PDL'),
      TextCellValue('DETECTEUR_CO_1'),
      TextCellValue('DETECTEUR_CO_2'),
      TextCellValue('LATITUDE'),
      TextCellValue('LONGITUDE'),
      TextCellValue('ENTREPRISE'),
    ]);

    for (final item in selected) {
      sheet.appendRow([
        TextCellValue(item.createdAt),
        TextCellValue(item.pdl),
        TextCellValue(item.detector1),
        TextCellValue(item.detector2),
        TextCellValue(item.latitude.toString()),
        TextCellValue(item.longitude.toString()),
        TextCellValue(item.enterprise),
      ]);
    }

    final bytes = excel.encode();
    if (bytes == null) {
      throw Exception('Impossible de générer le fichier Excel.');
    }

    final tempDir = await getTemporaryDirectory();
    final safeName = enterprise.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    final from = DateFormat('yyyy-MM-dd').format(startDate);
    final to = DateFormat('yyyy-MM-dd').format(endDate);
    final fileName = '${safeName}_${from}_$to.xlsx';
    final tempFile = File('${tempDir.path}/$fileName');
    await tempFile.writeAsBytes(bytes, flush: true);

    final savedPath = await FlutterFileDialog.saveFile(
      params: SaveFileDialogParams(
        sourceFilePath: tempFile.path,
        fileName: fileName,
      ),
    );
    return savedPath;
  }
}
