import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import '../models/intervention.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    _db = await openDatabase(
      p.join(dir.path, 'co_track_dz.db'),
      version: 2,
      onCreate: (db, version) async {
        await db.execute('''CREATE TABLE interventions(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          pdl TEXT NOT NULL UNIQUE,
          detector1 TEXT NOT NULL UNIQUE,
          detector2 TEXT NOT NULL UNIQUE,
          latitude REAL NOT NULL, longitude REAL NOT NULL,
          enterprise TEXT NOT NULL,
          bill_photo TEXT NOT NULL DEFAULT '',
          detector1_photo TEXT NOT NULL DEFAULT '',
          detector2_photo TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL)''');
        await _createCompanies(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        // Preserve every existing intervention and legacy photo reference.
        if (oldVersion < 2) await _createCompanies(db);
      },
    );
    return _db!;
  }

  static Future<void> _createCompanies(DatabaseExecutor db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS companies(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE COLLATE NOCASE,
      company_name TEXT NOT NULL,
      password_salt TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL)''');
  }

  Future<bool> registerCompany({
    required String username, required String companyName,
    required String salt, required String hash, required String createdAt,
  }) async {
    final db = await database;
    try {
      await db.insert('companies', {
        'username': username, 'company_name': companyName,
        'password_salt': salt, 'password_hash': hash, 'created_at': createdAt,
      }, conflictAlgorithm: ConflictAlgorithm.abort);
      return true;
    } on DatabaseException {
      return false;
    }
  }

  Future<Map<String, Object?>?> company(String username) async {
    final db = await database;
    final rows = await db.query('companies',
      where: 'username = ?', whereArgs: [username], limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<void> insert(Intervention item) async {
    final db = await database;
    await db.insert('interventions', item.toMap(),
      conflictAlgorithm: ConflictAlgorithm.abort);
  }

  Future<List<Intervention>> allForEnterprise(String enterprise) async {
    final db = await database;
    final rows = await db.query('interventions',
      where: 'enterprise = ?', whereArgs: [enterprise],
      orderBy: 'created_at DESC');
    return rows.map(Intervention.fromMap).toList();
  }

  Future<int> countToday(String enterprise, String datePrefix) async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT COUNT(*) AS total FROM interventions WHERE enterprise = ? AND created_at LIKE ?',
      [enterprise, '$datePrefix%']);
    return Sqflite.firstIntValue(result) ?? 0;
  }
}
