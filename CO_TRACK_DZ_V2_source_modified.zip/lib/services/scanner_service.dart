import 'package:mobile_scanner/mobile_scanner.dart';

class ScannerService {
  // The bill's encoded payload can vary by Sonelgaz bill format.
  // Never silently use Client number or EBB key as the PDL.
  static String? extractPdl(String raw) {
    final text = raw.replaceAll(RegExp(r'\s+'), ' ').trim();
    final candidates = RegExp(r'(?<!\d)27\d{6,20}(?!\d)')
        .allMatches(text).map((m) => m.group(0)!).toSet();
    if (candidates.length == 1) return candidates.first;
    return null;
  }

  static String? firstBarcode(BarcodeCapture capture) {
    for (final barcode in capture.barcodes) {
      final value = barcode.rawValue?.trim();
      if (value != null && value.isNotEmpty) return value;
    }
    return null;
  }
}
