import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';

class PasswordService {
  static String normalizeCompanyName(String value) =>
      value.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');

  static String _hex(List<int> bytes) =>
      bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();

  static String newSalt() {
    final random = Random.secure();
    return _hex(List<int>.generate(16, (_) => random.nextInt(256)));
  }

  // PBKDF2-HMAC-SHA256 (60,000 iterations, 256-bit output).
  static String hash(String password, String saltHex) {
    final salt = List<int>.generate(saltHex.length ~/ 2,
      (i) => int.parse(saltHex.substring(i * 2, i * 2 + 2), radix: 16));
    final hmac = Hmac(sha256, utf8.encode(password));
    final block = <int>[...salt, 0, 0, 0, 1];
    var u = hmac.convert(block).bytes;
    final result = List<int>.from(u);
    for (var i = 1; i < 60000; i++) {
      u = hmac.convert(u).bytes;
      for (var j = 0; j < result.length; j++) {
        result[j] ^= u[j];
      }
    }
    return _hex(result);
  }
}
