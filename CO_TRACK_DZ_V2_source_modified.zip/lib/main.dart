import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CoTrackApp());
}

class CoTrackApp extends StatelessWidget {
  const CoTrackApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CO TRACK DZ',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087E8B)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF087E8B),
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
      ),
      home: const LoginScreen(),
    );
  }
}

Future<String?> currentEnterprise() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('enterprise_username');
}

Future<void> openHome(BuildContext context, String username) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('enterprise_username', username.trim());
  if (!context.mounted) return;
  Navigator.of(context).pushReplacement(
    MaterialPageRoute(builder: (_) => HomeScreen(enterprise: username.trim())),
  );
}
