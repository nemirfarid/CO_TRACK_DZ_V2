import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:intl/intl.dart';
import '../models/intervention.dart';
import '../services/database_service.dart';
import '../services/scanner_service.dart';

class InterventionScreen extends StatefulWidget {
  final String enterprise;
  const InterventionScreen({super.key, required this.enterprise});
  @override
  State<InterventionScreen> createState() => _InterventionScreenState();
}
class _InterventionScreenState extends State<InterventionScreen> {
  final pdl = TextEditingController(), d1 = TextEditingController(), d2 = TextEditingController();
  Position? position;
  bool busy = false;
  @override
  void dispose() { pdl.dispose(); d1.dispose(); d2.dispose(); super.dispose(); }

  Future<void> scanInto(TextEditingController target, {bool billMode = false}) async {
    final value = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => const ScanPage()));
    if (value == null) return;
    if (billMode) {
      final found = ScannerService.extractPdl(value);
      if (found == null) { message('PDL non identifié avec certitude. Vérifiez la facture puis saisissez-le manuellement.'); return; }
      target.text = found;
    } else { target.text = value; }
  }

  Future<void> getGps() async {
    setState(() => busy = true);
    try {
      if (!await Geolocator.isLocationServiceEnabled()) throw Exception('Activez la localisation du téléphone.');
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) throw Exception('Permission GPS refusée.');
      position = await Geolocator.getCurrentPosition();
      if (mounted) setState(() {});
    } catch (e) { if (mounted) message('$e'); }
    finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> save() async {
    final reference = pdl.text.trim();
    if (!RegExp(r'^27\d{6,20}$').hasMatch(reference)) { message('La référence PDL doit commencer par 27 et être vérifiée.'); return; }
    if (d1.text.trim().isEmpty || d2.text.trim().isEmpty) { message('Scannez les deux détecteurs.'); return; }
    if (d1.text.trim() == d2.text.trim()) { message('Les deux numéros de détecteur sont identiques.'); return; }
    if (position == null) { message('Enregistrez la position GPS.'); return; }
    setState(() => busy = true);
    try {
      await DatabaseService.instance.insert(Intervention(
        pdl: reference, detector1: d1.text.trim(), detector2: d2.text.trim(),
        latitude: position!.latitude, longitude: position!.longitude,
        enterprise: widget.enterprise,
        createdAt: DateFormat("yyyy-MM-dd'T'HH:mm:ss").format(DateTime.now())));
      if (mounted) Navigator.pop(context, true);
    } catch (e) { message('Enregistrement impossible (doublon possible) : $e'); }
    finally { if (mounted) setState(() => busy = false); }
  }

  void message(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Nouvelle intervention')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      TextField(controller: pdl, decoration: InputDecoration(labelText: 'Référence PDL (27...)', border: const OutlineInputBorder(),
        suffixIcon: IconButton(icon: const Icon(Icons.qr_code_scanner), onPressed: () => scanInto(pdl, billMode: true)))),
      const SizedBox(height: 12),
      TextField(controller: d1, decoration: InputDecoration(labelText: 'Détecteur CO 1', border: const OutlineInputBorder(),
        suffixIcon: IconButton(icon: const Icon(Icons.qr_code_scanner), onPressed: () => scanInto(d1)))),
      const SizedBox(height: 12),
      TextField(controller: d2, decoration: InputDecoration(labelText: 'Détecteur CO 2', border: const OutlineInputBorder(),
        suffixIcon: IconButton(icon: const Icon(Icons.qr_code_scanner), onPressed: () => scanInto(d2)))),
      const SizedBox(height: 16),
      OutlinedButton.icon(onPressed: busy ? null : getGps, icon: const Icon(Icons.location_on),
        label: Text(position == null ? 'Capturer la position GPS' : '${position!.latitude}, ${position!.longitude}')),
      const SizedBox(height: 18),
      FilledButton(onPressed: busy ? null : save, child: Padding(padding: const EdgeInsets.all(14),
        child: Text(busy ? 'Veuillez patienter…' : 'ENREGISTRER L’INTERVENTION'))),
    ]));
}

class ScanPage extends StatefulWidget {
  const ScanPage({super.key});
  @override
  State<ScanPage> createState() => _ScanPageState();
}
class _ScanPageState extends State<ScanPage> {
  bool done = false;
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Scanner le code')),
    body: MobileScanner(onDetect: (capture) {
      if (done) return;
      final value = ScannerService.firstBarcode(capture);
      if (value != null) { done = true; Navigator.pop(context, value); }
    }));
}
