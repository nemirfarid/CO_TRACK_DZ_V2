import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../services/database_service.dart';
import '../services/export_service.dart';
import 'history_screen.dart';
import 'intervention_screen.dart';

class HomeScreen extends StatefulWidget {
  final String enterprise;
  const HomeScreen({super.key, required this.enterprise});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int count = 0;
  bool exporting = false;

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    final date = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final total = await DatabaseService.instance.countToday(widget.enterprise, date);
    if (mounted) setState(() => count = total);
  }

  Future<void> exportExcel() async {
    final now = DateTime.now();
    final range = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(now.year + 1, 12, 31),
      initialDateRange: DateTimeRange(
        start: DateTime(now.year, now.month, now.day),
        end: DateTime(now.year, now.month, now.day),
      ),
      helpText: 'Choisir la période à exporter',
      saveText: 'Continuer',
      cancelText: 'Annuler',
    );
    if (range == null || !mounted) return;

    setState(() => exporting = true);
    try {
      final items = await DatabaseService.instance.allForEnterprise(widget.enterprise);
      final savedPath = await ExportService.exportRange(
        enterprise: widget.enterprise,
        items: items,
        start: range.start,
        end: range.end,
      );
      if (!mounted) return;
      final message = savedPath == null
          ? 'Enregistrement annulé. Aucune donnée n’a été supprimée.'
          : 'Fichier Excel enregistré : $savedPath';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message), duration: const Duration(seconds: 6)),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur export Excel : $error')),
      );
    } finally {
      if (mounted) setState(() => exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('CO TRACK DZ'),
          actions: [
            IconButton(
              tooltip: 'Historique',
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => HistoryScreen(enterprise: widget.enterprise),
                  ),
                );
                refresh();
              },
              icon: const Icon(Icons.history),
            ),
          ],
        ),
        body: RefreshIndicator(
          onRefresh: refresh,
          child: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Entreprise connectée', style: TextStyle(color: Colors.grey)),
                      Text(widget.enterprise, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 18),
                      const Text('Interventions du jour'),
                      Text('$count', style: const TextStyle(fontSize: 42, fontWeight: FontWeight.bold, color: Color(0xFF087E8B))),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () async {
                  final saved = await Navigator.push<bool>(
                    context,
                    MaterialPageRoute(
                      builder: (_) => InterventionScreen(enterprise: widget.enterprise),
                    ),
                  );
                  if (saved == true) refresh();
                },
                icon: const Icon(Icons.add_location_alt),
                label: const Padding(
                  padding: EdgeInsets.all(14),
                  child: Text('NOUVELLE INTERVENTION'),
                ),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: exporting ? null : exportExcel,
                icon: exporting
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.file_download),
                label: Text(exporting ? 'Préparation du fichier…' : 'Exporter Excel (choisir période et dossier)'),
              ),
              const Padding(
                padding: EdgeInsets.only(top: 5, left: 4, right: 4),
                child: Text(
                  'Le fichier sera enregistré dans le dossier choisi (par exemple Téléchargements). Les interventions restent conservées dans l’application.',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => HistoryScreen(enterprise: widget.enterprise),
                  ),
                ),
                icon: const Icon(Icons.list_alt),
                label: const Text('Historique des interventions'),
              ),
            ],
          ),
        ),
      );
}
