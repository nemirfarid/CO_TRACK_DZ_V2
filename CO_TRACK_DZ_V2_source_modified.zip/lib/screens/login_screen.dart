import 'package:flutter/material.dart';
import '../main.dart';
import '../services/database_service.dart';
import '../services/password_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final company = TextEditingController(), pass = TextEditingController();
  final confirm = TextEditingController();
  bool obscure = true, registering = false, busy = false;
  @override
  void dispose() { company.dispose(); pass.dispose(); confirm.dispose(); super.dispose(); }

  void message(String text) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(text)));

  Future<void> submit() async {
    final name = company.text.trim();
    final username = PasswordService.normalizeCompanyName(name);
    if (name.length < 2) { message('Saisissez le nom de votre entreprise.'); return; }
    if (pass.text.length < 10) { message('Le mot de passe doit contenir au moins 10 caractères.'); return; }
    if (registering && pass.text != confirm.text) { message('Les deux mots de passe ne correspondent pas.'); return; }
    setState(() => busy = true);
    try {
      final db = DatabaseService.instance;
      if (registering) {
        final salt = PasswordService.newSalt();
        final ok = await db.registerCompany(username: username,
          companyName: name, salt: salt,
          hash: PasswordService.hash(pass.text, salt),
          createdAt: DateTime.now().toIso8601String());
        if (!ok) { message('Ce nom d’entreprise est déjà enregistré sur cet appareil.'); return; }
      } else {
        final account = await db.company(username);
        if (account == null ||
            PasswordService.hash(pass.text, account['password_salt'] as String) != account['password_hash']) {
          message('Entreprise ou mot de passe incorrect.'); return;
        }
      }
      if (!mounted) return;
      await openHome(context, username);
    } catch (e) { message('Erreur : $e'); }
    finally { if (mounted) setState(() => busy = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(22),
      child: Card(child: Padding(padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.sensors, size: 64, color: Color(0xFF087E8B)),
          const SizedBox(height: 10),
          const Text('CO TRACK DZ', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
          const Text('Suivi des installations de détecteurs CO'),
          const SizedBox(height: 24),
          TextField(controller: company, textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(labelText: 'Nom de l’entreprise', prefixIcon: Icon(Icons.business), border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: pass, obscureText: obscure,
            decoration: InputDecoration(labelText: 'Mot de passe', prefixIcon: const Icon(Icons.lock_outline),
              suffixIcon: IconButton(icon: Icon(obscure ? Icons.visibility : Icons.visibility_off),
                onPressed: () => setState(() => obscure = !obscure)),
              border: const OutlineInputBorder())),
          if (registering) ...[
            const SizedBox(height: 12),
            TextField(controller: confirm, obscureText: true,
              decoration: const InputDecoration(labelText: 'Confirmer le mot de passe', prefixIcon: Icon(Icons.verified_user_outlined), border: OutlineInputBorder())),
          ],
          const SizedBox(height: 20),
          SizedBox(width: double.infinity, child: FilledButton(
            onPressed: busy ? null : submit,
            child: Padding(padding: const EdgeInsets.all(13),
              child: Text(busy ? 'Veuillez patienter…' : registering ? 'CRÉER MON COMPTE' : 'SE CONNECTER')))),
          TextButton(onPressed: busy ? null : () => setState(() => registering = !registering),
            child: Text(registering ? 'J’ai déjà un compte' : 'Créer un compte entreprise')),
          const Text('Compte activé immédiatement sur cet appareil. Les données restent locales.',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.grey)),
        ]),
      )),
    ))),
  );
}
