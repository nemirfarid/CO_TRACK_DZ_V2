import 'package:flutter/material.dart';
import '../models/intervention.dart';
import '../services/database_service.dart';

class HistoryScreen extends StatefulWidget {
  final String enterprise;
  const HistoryScreen({super.key, required this.enterprise});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}
class _HistoryScreenState extends State<HistoryScreen> {
  late Future<List<Intervention>> future;
  @override
  void initState() { super.initState(); future = DatabaseService.instance.allForEnterprise(widget.enterprise); }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Historique')),
    body: FutureBuilder<List<Intervention>>(future: future, builder: (context, snap) {
      if (snap.hasError) return Center(child: Text('Erreur : ${snap.error}'));
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final items = snap.data!;
      if (items.isEmpty) return const Center(child: Text('Aucune intervention enregistrée.'));
      return ListView.builder(itemCount: items.length, itemBuilder: (context, i) {
        final x = items[i];
        return Card(margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: ListTile(leading: const CircleAvatar(child: Icon(Icons.sensors)),
            title: Text('PDL ${x.pdl}'),
            subtitle: Text('${x.createdAt}\nDétecteurs : ${x.detector1} / ${x.detector2}\nGPS : ${x.latitude}, ${x.longitude}'),
            isThreeLine: true));
      });
    }));
}
