class Intervention {
  final int? id;
  final String pdl, detector1, detector2, enterprise, createdAt;
  final double latitude, longitude;
  // Legacy fields retained only for reading older SQLite rows.
  final String billPhoto, detector1Photo, detector2Photo;
  const Intervention({this.id, required this.pdl, required this.detector1,
    required this.detector2, required this.latitude, required this.longitude,
    required this.enterprise, this.billPhoto = '', this.detector1Photo = '',
    this.detector2Photo = '', required this.createdAt});

  Map<String, Object?> toMap() => {
    'id': id, 'pdl': pdl, 'detector1': detector1, 'detector2': detector2,
    'latitude': latitude, 'longitude': longitude, 'enterprise': enterprise,
    // Old schema columns are NOT NULL; empty values preserve schema compatibility.
    'bill_photo': '', 'detector1_photo': '', 'detector2_photo': '',
    'created_at': createdAt,
  };

  factory Intervention.fromMap(Map<String, Object?> m) => Intervention(
    id: m['id'] as int?, pdl: m['pdl'] as String,
    detector1: m['detector1'] as String, detector2: m['detector2'] as String,
    latitude: (m['latitude'] as num).toDouble(), longitude: (m['longitude'] as num).toDouble(),
    enterprise: m['enterprise'] as String,
    billPhoto: (m['bill_photo'] as String?) ?? '',
    detector1Photo: (m['detector1_photo'] as String?) ?? '',
    detector2Photo: (m['detector2_photo'] as String?) ?? '',
    createdAt: m['created_at'] as String,
  );
}
