# CO TRACK DZ — source V2

Application Flutter Android de suivi des interventions d'installation de détecteurs de monoxyde de carbone.

## Changements V2 préparés
- Inscription d'une entreprise depuis l'écran d'accueil, sans validation manuelle.
- Identifiant calculé depuis le nom de l'entreprise : minuscules et espaces normalisés.
- Contrôle d'unicité de l'identifiant dans la base locale.
- Mot de passe personnel (minimum 10 caractères), confirmation à l'inscription et stockage sous forme de dérivé PBKDF2-HMAC-SHA256 avec sel aléatoire.
- Suppression de la capture et de l'affichage des photos d'intervention.
- Saisie/scanner des références PDL et des deux détecteurs, GPS, historique et export Excel conservés.
- Icône Android personnalisée autour d'un détecteur CO. Aucun symbole de croix médicale n'est utilisé.
- Migration SQLite non destructive : la table des interventions existante n'est pas supprimée. Les anciennes colonnes photo sont conservées pour compatibilité, mais ne sont plus utilisées. Les nouvelles interventions y enregistrent des chaînes vides.

## Limite importante — comptes locaux
Cette archive est une application hors ligne. Les comptes et mots de passe sont enregistrés uniquement dans la base SQLite de cet appareil. L'unicité du nom d'entreprise n'est donc garantie que sur cet appareil, pas entre plusieurs téléphones. Il n'existe pas encore de serveur d'inscription, d'authentification distante ni de synchronisation. Une véritable séparation inter-entreprises entre appareils nécessite un backend sécurisé et une stratégie de migration/synchronisation.

## Données préexistantes
La migration ajoute une table `companies` et ne supprime aucune ligne de `interventions`. Les anciens enregistrements gardent leur valeur `enterprise` originale. Ils ne sont pas automatiquement réattribués à un nouvel identifiant normalisé : il faut vérifier leur rattachement avant mise en production. Les anciennes références de photos peuvent rester dans SQLite, mais l'application V2 ne les affiche plus et ne capture plus de nouvelles photos.

## Construction APK
Le workflow GitHub Actions construit l'APK Android release. Après extraction de l'archive dans un dépôt, vérifier que le dépôt contient bien le projet Flutter et lancer :
- `flutter pub get`
- `dart run flutter_launcher_icons`
- `flutter analyze`
- `flutter test`
- `flutter build apk --release`

## Vérifications indispensables avant utilisation réelle
- Tester la migration sur une copie de la base existante et vérifier le nombre d'interventions avant/après.
- Tester les codes Data Matrix/QR réels des détecteurs et factures Sonelgaz anonymisées.
- Pour un déploiement multi-téléphones, ajouter un backend avec authentification, isolation côté serveur, sauvegardes et règles de récupération de compte.
